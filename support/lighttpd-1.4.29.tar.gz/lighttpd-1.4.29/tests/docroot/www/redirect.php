<?php

	header('Location: http://www.example.org:2048/');
?>
